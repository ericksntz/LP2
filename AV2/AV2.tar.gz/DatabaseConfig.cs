namespace AV2.Database;

class DatabaseConfig
{
    public string ConnectionString { get => "Data Source=database.db"; }
}